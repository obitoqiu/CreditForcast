1.赛题请参考 https://js.dclab.run/v2/cmptDetail.html?id=230，里面有题目背景和数据的介绍；
2.机器学习基础请参考：https://software.intel.com/content/www/us/en/develop/training/course-machine-learning.html